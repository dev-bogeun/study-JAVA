package anonymousTest;

public abstract class FormAdapter implements Form {

	@Override
	public void sell(String order) {;}

}
