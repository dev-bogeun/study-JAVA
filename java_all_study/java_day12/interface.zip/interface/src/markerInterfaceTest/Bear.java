package markerInterfaceTest;

public class Bear extends Animal implements CarnivoreMarker {

}
