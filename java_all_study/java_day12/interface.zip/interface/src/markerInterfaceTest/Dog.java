package markerInterfaceTest;

public class Dog extends Animal {

}
