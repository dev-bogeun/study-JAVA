package arrayListTask;

import java.util.ArrayList;

import arrayListTask.food.Food;
import arrayListTask.fruit.Fruit;
import arrayListTask.love.Love;
import arrayListTask.user.User;

public class DBConnecter {
	public static ArrayList<User> users = new ArrayList<User>();
	public static ArrayList<Fruit> furits = new ArrayList<Fruit>();
	public static ArrayList<Food> foods = new ArrayList<Food>();
	public static ArrayList<Love> loves = new ArrayList<Love>();
}
