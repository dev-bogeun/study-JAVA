package variableTest;

public class VariableTest {
	public static void main(String[] args) {
		int age = 10;
		float floatNumber = 10.1563F;
		double doubleNumber = 10.1563;
		char grade = 'A';
		String data = "ABC";
		
		System.out.println(age);
		System.out.println(floatNumber);
		System.out.println(doubleNumber);
		System.out.println(grade);
		System.out.println(data);
	}
}
