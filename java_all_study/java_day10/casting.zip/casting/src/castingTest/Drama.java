package castingTest;

public class Drama extends Video {
	public void sellGoods() {
		System.out.println("����");
	}
}
