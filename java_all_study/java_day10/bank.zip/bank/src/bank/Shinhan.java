package bank;

public class Shinhan extends Bank{

}
