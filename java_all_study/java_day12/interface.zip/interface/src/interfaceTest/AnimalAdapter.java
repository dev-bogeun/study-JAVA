package interfaceTest;

public abstract class AnimalAdapter implements Animal {

	@Override
	public void sitDown() {;}

	@Override
	public void showHands() {;}

	@Override
	public void touchNose() {;}

	@Override
	public void waitNow() {;}

}
