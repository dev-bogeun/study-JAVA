package ambiguity;

public class ClassA {
	public void printName() {
		System.out.println("ClassA");
	}
}
