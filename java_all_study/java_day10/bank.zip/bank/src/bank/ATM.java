package bank;

public class ATM {
	public static void main(String[] args) {
		Bank[][] arrBank = new Bank[3][100];
		int[] arCount = new int[3];
		
//		while() { 
//			while() {
//				
//			}
//		}
	}
}
