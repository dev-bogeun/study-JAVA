package markerInterfaceTest;

public class Tiger extends Animal implements CarnivoreMarker{

}
