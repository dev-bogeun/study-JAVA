package stringTest;

public class StringTest {
	public static void main(String[] args) {
		String data = "ABC";
		System.out.println(data.length());
		System.out.println(data.charAt(1));
		System.out.println(data.indexOf('C'));
	}
}
