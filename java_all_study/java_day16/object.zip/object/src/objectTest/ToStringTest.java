package objectTest;

public class ToStringTest {
	public static void main(String[] args) {
		Student student = new Student(1, "�ѵ���");
		System.out.println(student);
	}
}
