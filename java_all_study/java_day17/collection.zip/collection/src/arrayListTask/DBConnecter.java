package arrayListTask;

import java.util.ArrayList;

import arrayListTask.user.User;

public class DBConnecter {
	public static ArrayList<User> users = new ArrayList<User>();
}
