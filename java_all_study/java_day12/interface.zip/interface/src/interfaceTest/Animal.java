package interfaceTest;

public interface Animal {
	
	int eyes = 2;
	final static int nose = 1;
	
	abstract void sitDown();
	void showHands();
	void touchNose();
	void waitNow();
	void poop();
}
