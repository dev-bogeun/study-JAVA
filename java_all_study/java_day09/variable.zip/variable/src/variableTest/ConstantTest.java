package variableTest;

public class ConstantTest {
	public static void main(String[] args) {
		final int ON = 501561;
		final int OFF = 501321;
		
		System.out.println(ON);
		System.out.println(OFF);
	}
}
