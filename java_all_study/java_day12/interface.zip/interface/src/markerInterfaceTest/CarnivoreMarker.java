package markerInterfaceTest;

public interface CarnivoreMarker {;}
