package abstractTest;

public class WashingMachine extends Electronics{

	@Override
	public void on() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void printProduct() {
		// TODO Auto-generated method stub
		super.printProduct();
	}
}










