package classTest;

public class ClassTask2 {
	public static void main(String[] args) {
		Student student = new Student(1, 50, 60, 90);
		System.out.println(student.total);
		System.out.println(student.average);
	}
}
