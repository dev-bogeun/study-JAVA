package access1;

public class VariableTest {
	public static void main(String[] args) {
		Variable variable = new Variable();
	}
}
