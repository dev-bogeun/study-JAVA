package lambdaTask;

@FunctionalInterface
public interface Calc {
	public int calc(int number1, int number2);
}
