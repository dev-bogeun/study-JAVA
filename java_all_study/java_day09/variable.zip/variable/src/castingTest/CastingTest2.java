package castingTest;

public class CastingTest2 {
	public static void main(String[] args) {
		char data = 48;
		System.out.println('A' + 3);
		System.out.println((int)data);
	}
}
