package date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

public class DateTest {
	public static void main(String[] args) {
		
//		LocalDate localDate = LocalDate.parse("2025/05/04".replace("/", "-"));
//		System.out.println(localDate);
		
//		LocalDateTime localDateTime = LocalDateTime.of(2010, 4, 5, 10, 0);
//		String format = localDateTime.format(DateTimeFormatter.ofPattern("yyyy�� MM�� dd�� HH�� mm�� ss��"));
//
//		System.out.println(localDateTime);
//		System.out.println(format);
		
//		LocalDate localDate = LocalDate.of(2020, 12, 4);
//		String format = localDate.format(DateTimeFormatter.ofPattern("yyyy�� MM�� dd��"));
//		System.out.println(localDate);
//		System.out.println(format);
//		System.out.println(localDate.getMonthValue());
		
//		SimpleDateFormat format = new SimpleDateFormat("yyyy�� MM�� dd�� HH:mm:ss");
//		Calendar calendar = Calendar.getInstance();
//		System.out.println(format.format(calendar.getTime()));
		
//		Date date = new Date();
		
//		System.out.println(date);
//		System.out.println(format.format(date));
//		try {
//			date = format.parse("2024�� 06�� 12�� 10:00:11");
//			System.out.println(date);
//		} catch (ParseException e) {;}
	}
}










