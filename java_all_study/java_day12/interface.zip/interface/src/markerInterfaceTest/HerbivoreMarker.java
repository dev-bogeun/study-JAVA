package markerInterfaceTest;

public interface HerbivoreMarker {;}
