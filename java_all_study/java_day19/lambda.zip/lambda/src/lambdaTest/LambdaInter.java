package lambdaTest;

@FunctionalInterface
public interface LambdaInter {
	public boolean checkMultipleOf10(int number);
}
