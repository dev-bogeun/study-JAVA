package castingTest;

public class Film extends Video {
	public void moveChair() {
		System.out.println("4D");
	}
}
