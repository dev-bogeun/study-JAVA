package ambiguity;

public interface InterA {
	default void printName() {
		System.out.println("InterA");
	}
}
