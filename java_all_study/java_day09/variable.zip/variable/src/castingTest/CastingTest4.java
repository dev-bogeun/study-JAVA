package castingTest;

public class CastingTest4 {
	public static void main(String[] args) {
		System.out.println(Integer.parseInt("1") + 3 + 9);
		System.out.println(Double.parseDouble("3.9") + 9);
	}
}
