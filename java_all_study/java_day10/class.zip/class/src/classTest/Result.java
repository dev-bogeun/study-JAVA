package classTest;

public class Result {
	int max;
	int min;
}
