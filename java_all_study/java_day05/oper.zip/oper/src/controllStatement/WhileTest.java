package controllStatement;

public class WhileTest {
	public static void main(String[] args) {
//		�̸� 10�� ���
		int count = 0;
		
		while(count != 10) {
			System.out.println(count + ".�ѵ���");
			count++;
		}
	}
}
